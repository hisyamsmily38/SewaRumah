import { useState, useEffect } from 'react';
import { Category, categories } from './data/listings';
import { useListingsStore, adjustColor, colorWithAlpha } from './store';
import Header from './components/Header';
import Hero from './components/Hero';
import CategoryFilter from './components/CategoryFilter';
import ListingCard from './components/ListingCard';
import ListingDetail from './components/ListingDetail';
import Footer from './components/Footer';
import AdminPanel from './components/AdminPanel';
import AdminLogin from './components/AdminLogin';
import TenantForm from './components/TenantForm';
import ContactModal from './components/ContactModal';

type FilterType = Category | 'semua';

export default function App() {
  const { listings, settings } = useListingsStore();
  const [selectedCategory, setSelectedCategory] = useState<FilterType>('semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedListing, setSelectedListing] = useState<(typeof listings)[0] | null>(null);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showTenantForm, setShowTenantForm] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [targetListingTitle, setTargetListingTitle] = useState<string | undefined>(undefined);

  // Apply CSS custom properties from settings
  useEffect(() => {
    const p = settings.primaryColor;
    const root = document.documentElement;
    root.style.setProperty('--theme-primary', p);
    root.style.setProperty('--theme-primary-light', adjustColor(p, 180));
    root.style.setProperty('--theme-primary-50', colorWithAlpha(p, 0.06));
    root.style.setProperty('--theme-primary-100', colorWithAlpha(p, 0.15));
    root.style.setProperty('--theme-primary-200', colorWithAlpha(p, 0.3));
    root.style.setProperty('--theme-primary-dark', adjustColor(p, -30));
    root.style.setProperty('--theme-primary-900', adjustColor(p, -80));
    root.style.setProperty('--theme-primary-shadow', colorWithAlpha(p, 0.2));
    root.style.setProperty('--theme-primary-teal', adjustColor(p, -15));
  }, [settings.primaryColor]);

  const filteredListings = listings.filter((listing) => {
    const matchCategory = selectedCategory === 'semua' || listing.category === selectedCategory;
    const matchSearch =
      searchQuery === '' ||
      listing.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      listing.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCategory && matchSearch;
  });

  const getCategoryTitle = (): string => {
    if (selectedCategory === 'semua') return 'Semua Senarai Sewa';
    const cat = categories.find((c) => c.id === selectedCategory);
    return `${cat?.icon} ${cat?.label}`;
  };

  const openTenantRegistration = (listingTitle?: string) => {
    setTargetListingTitle(listingTitle);
    setShowTenantForm(true);
  };

  const handleAdminClick = () => {
    setShowAdminLogin(true);
  };

  const handleAdminLoginSuccess = () => {
    setShowAdminLogin(false);
    setShowAdminPanel(true);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header
        onAdminClick={handleAdminClick}
        onTenantRegisterClick={() => openTenantRegistration()}
        onContactClick={() => setShowContactModal(true)}
      />

      <Hero onTenantRegisterClick={() => openTenantRegistration()} />

      <CategoryFilter selected={selectedCategory} onChange={setSelectedCategory} />

      {/* Listings Section */}
      <section id="senarai" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="inline-block bg-theme-100 text-theme-dark text-sm font-semibold px-4 py-1.5 rounded-full mb-4">Senarai</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-4">{getCategoryTitle()}</h2>
            <p className="text-gray-500 text-lg max-w-xl mx-auto">{filteredListings.length} senarai dijumpai</p>
          </div>

          <div className="max-w-lg mx-auto mb-12">
            <div className="relative">
              <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input type="text" placeholder="Cari mengikut nama atau lokasi..." value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 ring-theme focus:border-transparent transition-all" />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              )}
            </div>
          </div>

          {filteredListings.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredListings.map((listing) => (
                <ListingCard key={listing.id} listing={listing} onClick={() => setSelectedListing(listing)} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Tiada Keputusan Ditemui</h3>
              <p className="text-gray-500 mb-6">Cuba ubah carian atau kategori anda.</p>
              <button onClick={() => { setSearchQuery(''); setSelectedCategory('semua'); }}
                className="bg-theme text-white px-6 py-3 rounded-2xl font-semibold hover-bg-theme transition-colors">Reset Penapis</button>
            </div>
          )}
        </div>
      </section>

      <Footer onTenantRegisterClick={() => openTenantRegistration()} onContactClick={() => setShowContactModal(true)} />

      {selectedListing && (
        <ListingDetail listing={selectedListing} onApplyClick={(title) => openTenantRegistration(title)} onClose={() => setSelectedListing(null)} />
      )}
      {showTenantForm && <TenantForm initialListingTitle={targetListingTitle} onClose={() => setShowTenantForm(false)} />}
      {showContactModal && <ContactModal onClose={() => setShowContactModal(false)} />}
      {showAdminLogin && <AdminLogin onClose={() => setShowAdminLogin(false)} onLoginSuccess={handleAdminLoginSuccess} />}
      {showAdminPanel && <AdminPanel onClose={() => setShowAdminPanel(false)} />}
    </div>
  );
}
