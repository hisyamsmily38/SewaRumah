import { Listing } from '../data/listings';
import { useListingsStore } from '../store';

interface Props {
  listing: Listing | null;
  onApplyClick: (listingTitle: string) => void;
  onClose: () => void;
}

export default function ListingDetail({ listing, onApplyClick, onClose }: Props) {
  const { settings: s } = useListingsStore();

  if (!listing) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in" />
      <div className="relative bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 z-10 bg-white/90 backdrop-blur-md rounded-full p-2 hover:bg-white transition-colors shadow-lg">
          <svg className="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="relative h-64 sm:h-80 overflow-hidden rounded-t-3xl">
          <img src={listing.image} alt={listing.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          <div className="absolute bottom-6 left-6 right-6">
            <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold mb-3 ${
              listing.category === 'bilik' ? 'bg-blue-500/90 text-white' : 'bg-theme text-white'
            }`}>
              {listing.category === 'bilik' ? s.catBilikIcon : s.catRumahIcon} {listing.category === 'bilik' ? s.catBilikName : s.catRumahName}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">{listing.title}</h2>
          </div>
        </div>

        <div className="p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-6 border-b border-gray-100">
            <div className="text-3xl font-extrabold text-theme">RM{listing.price.toLocaleString()}<span className="text-base font-medium text-gray-400">/bulan</span></div>
            <div className="flex items-center gap-2 text-gray-500">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              <span className="font-medium">{listing.location}</span>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-lg font-bold text-gray-900 mb-3">Penerangan</h3>
            <p className="text-gray-600 leading-relaxed">{listing.description}</p>
          </div>

          <div className="mb-8">
            <h3 className="text-lg font-bold text-gray-900 mb-3">Kemudahan</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {listing.features.map((f) => (
                <div key={f} className="flex items-center gap-2 bg-gray-50 rounded-xl px-4 py-3">
                  <svg className="w-4 h-4 text-theme flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span className="text-sm text-gray-700 font-medium">{f}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-theme-50 rounded-3xl p-6 text-center border border-theme-200">
            <h4 className="text-lg font-bold text-gray-900 mb-2">Berminat dengan unit ini?</h4>
            <p className="text-gray-600 text-sm mb-6 max-w-md mx-auto">Anda boleh memohon sewa secara terus atau hubungi pemilik.</p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button onClick={() => { onClose(); onApplyClick(listing.title); }}
                className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 bg-theme text-white px-6 py-3.5 rounded-2xl font-bold text-base hover-bg-theme transition-colors shadow-theme">
                📝 Mohon Sewa Unit Ini
              </button>
              <a href={`tel:${listing.contact}`}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-white text-theme-dark border border-theme-200 px-6 py-3.5 rounded-2xl font-bold text-base hover:bg-gray-50 transition-colors shadow-sm">
                <svg className="w-5 h-5 text-theme" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                {listing.contact}
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
