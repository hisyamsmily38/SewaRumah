import { Category } from '../data/listings';
import { useListingsStore } from '../store';

interface Props {
  selected: Category | 'semua';
  onChange: (category: Category | 'semua') => void;
}

export default function CategoryFilter({ selected, onChange }: Props) {
  const { settings: s } = useListingsStore();

  const cats = [
    { id: 'bilik' as Category, label: s.catBilikName, icon: s.catBilikIcon, desc: s.catBilikDesc },
    { id: 'rumah' as Category, label: s.catRumahName, icon: s.catRumahIcon, desc: s.catRumahDesc },
  ];

  return (
    <section id="kategori" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <span className="inline-block bg-theme-100 text-theme-dark text-sm font-semibold px-4 py-1.5 rounded-full mb-4">Kategori</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mb-4">Pilih Jenis Perumahan</h2>
          <p className="text-gray-500 text-lg max-w-xl mx-auto">Pilih kategori yang anda cari.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-2xl mx-auto mb-10">
          {cats.map((cat) => (
            <button key={cat.id} onClick={() => onChange(cat.id)}
              className={`group relative p-8 rounded-3xl border-2 transition-all duration-300 text-left hover:-translate-y-1 ${
                selected === cat.id ? 'border-theme bg-theme-50 shadow-xl' : 'border-gray-200 bg-white hover:border-theme-200 hover:shadow-lg'
              }`}>
              {selected === cat.id && (
                <div className="absolute top-4 right-4">
                  <svg className="w-6 h-6 text-theme" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
              <div className="text-5xl mb-4">{cat.icon}</div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{cat.label}</h3>
              <p className="text-gray-500 text-sm">{cat.desc}</p>
            </button>
          ))}
        </div>

        <div className="flex items-center justify-center gap-3 flex-wrap">
          <button onClick={() => onChange('semua')}
            className={`px-6 py-2.5 rounded-full font-semibold text-sm transition-all ${
              selected === 'semua' ? 'bg-theme text-white shadow-theme' : 'bg-white text-gray-600 border border-gray-200 hover:border-theme-200 hover:text-theme'
            }`}>
            Semua
          </button>
          {cats.map((cat) => (
            <button key={cat.id} onClick={() => onChange(cat.id)}
              className={`px-6 py-2.5 rounded-full font-semibold text-sm transition-all ${
                selected === cat.id ? 'bg-theme text-white shadow-theme' : 'bg-white text-gray-600 border border-gray-200 hover:border-theme-200 hover:text-theme'
              }`}>
              {cat.icon} {cat.label}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
