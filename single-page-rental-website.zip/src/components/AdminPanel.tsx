import { useState } from 'react';
import { useListingsStore, themePresets, adjustColor, colorWithAlpha } from '../store';
import type { Listing } from '../data/listings';

interface Props {
  onClose: () => void;
}

type AdminTab = 'branding' | 'colors' | 'hero' | 'categories' | 'contact' | 'footer' | 'tenant' | 'listings' | 'tenants' | 'security';

const mainAdminTabs: { id: AdminTab; label: string; icon: string }[] = [
  { id: 'branding', label: 'Merek & Logo', icon: '🏢' },
  { id: 'colors', label: 'Warna & Tema', icon: '🎨' },
  { id: 'hero', label: 'Halaman Utama', icon: '🖼️' },
  { id: 'categories', label: 'Kategori', icon: '📂' },
  { id: 'contact', label: 'Hubungan', icon: '📞' },
  { id: 'footer', label: 'Footer', icon: '📄' },
  { id: 'tenant', label: 'Borang Penyewa', icon: '📝' },
  { id: 'listings', label: 'Senarai Unit', icon: '🏠' },
  { id: 'tenants', label: 'Data Penyewa', icon: '👥' },
  { id: 'security', label: 'Keselamatan', icon: '🔒' },
];

const staffAdminTabs: { id: AdminTab; label: string; icon: string }[] = [
  { id: 'listings', label: 'Senarai Sewa', icon: '🏠' },
  { id: 'tenants', label: 'Semak Penyewa', icon: '👥' },
];

export default function AdminPanel({ onClose }: Props) {
  const { listings, addListing, updateListing, deleteListing, resetListings, tenants, deleteTenant, settings, updateSettings, resetSettings, resetAll, adminRole, logoutAdmin } = useListingsStore();
  const [activeTab, setActiveTab] = useState<AdminTab>(adminRole === 'staff' ? 'listings' : 'branding');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ title: '', category: 'bilik' as 'bilik' | 'rumah', price: 0, location: '', image: '', description: '', features: '', contact: '' });

  const isMainAdmin = adminRole === 'main';
  const visibleTabs = isMainAdmin ? mainAdminTabs : staffAdminTabs;
  const s = settings;
  const set = (key: string, value: string | number) => updateSettings({ [key]: value });

  const handleLogout = () => { logoutAdmin(); onClose(); };

  // Listing CRUD
  const startEdit = (listing: Listing) => {
    setEditingId(listing.id);
    setFormData({ title: listing.title, category: listing.category, price: listing.price, location: listing.location, image: listing.image, description: listing.description, features: listing.features.join(', '), contact: listing.contact });
    setShowForm(true);
  };
  const startAdd = () => {
    setEditingId(null);
    setFormData({ title: '', category: 'bilik', price: 0, location: '', image: '', description: '', features: '', contact: '' });
    setShowForm(true);
  };
  const handleSave = () => {
    const featuresArr = formData.features.split(',').map((f) => f.trim()).filter((f) => f.length > 0);
    if (editingId !== null) { updateListing(editingId, { ...formData, features: featuresArr }); }
    else { addListing({ ...formData, features: featuresArr }); }
    setShowForm(false);
  };
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) { const reader = new FileReader(); reader.onloadend = () => { setFormData((p) => ({ ...p, image: reader.result as string })); }; reader.readAsDataURL(file); }
  };
  const handleSettingImageUpload = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) { const reader = new FileReader(); reader.onloadend = () => { updateSettings({ [key]: reader.result as string }); }; reader.readAsDataURL(file); }
  };

  // Input component
  const Field = ({ label, value, onChange, placeholder, type = 'text', rows }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string; rows?: number }) => (
    <div>
      <label className="block text-sm font-semibold text-gray-700 mb-1.5">{label}</label>
      {rows ? (
        <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={rows} placeholder={placeholder} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all resize-none text-gray-900" />
      ) : (
        <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all text-gray-900" />
      )}
    </div>
  );

  // Image Upload Block
  const ImageUpload = ({ label, value, onUpload, onRemove, previewClass = 'w-24 h-24' }: { label: string; value: string; onUpload: (e: React.ChangeEvent<HTMLInputElement>) => void; onRemove: () => void; previewClass?: string }) => (
    <div>
      <label className="block text-sm font-semibold text-gray-700 mb-2">{label}</label>
      <div className="flex items-start gap-4">
        {value ? (
          <div className="relative group">
            <img src={value} alt="Preview" className={`${previewClass} object-cover rounded-xl border-2 border-gray-200`} />
            <button onClick={onRemove} className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full text-xs font-bold opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center shadow-lg">✕</button>
          </div>
        ) : (
          <div className={`${previewClass} bg-gray-100 rounded-xl border-2 border-dashed border-gray-300 flex items-center justify-center text-gray-400 text-2xl`}>📷</div>
        )}
        <div className="flex-1">
          <label className="cursor-pointer inline-flex items-center gap-2 bg-gray-50 text-gray-700 px-4 py-2.5 rounded-xl font-medium hover:bg-gray-100 transition-colors border border-gray-200 text-sm">
            📤 Pilih Gambar <input type="file" accept="image/*" onChange={onUpload} className="hidden" />
          </label>
          <p className="text-xs text-gray-400 mt-1.5">JPG, PNG, WebP. Maks 5MB.</p>
        </div>
      </div>
    </div>
  );

  // ===== LISTING FORM OVERLAY =====
  if (showForm) {
    return (
      <div className="fixed inset-0 z-[120] flex items-start justify-center p-4 pt-8 sm:pt-16 overflow-y-auto">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
        <div className="relative bg-white rounded-3xl max-w-2xl w-full shadow-2xl p-6 sm:p-8 mb-8 animate-scale-in">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-extrabold text-gray-900">{editingId !== null ? '✏️ Edit Listing' : '➕ Tambah Listing Baru'}</h2>
            <button onClick={() => setShowForm(false)} className="p-2 hover:bg-gray-100 rounded-full"><svg className="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
          </div>
          <div className="space-y-4">
            <ImageUpload label="Gambar Unit" value={formData.image} onUpload={handleImageUpload} onRemove={() => setFormData((p) => ({ ...p, image: '' }))} />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Tajuk" value={formData.title} onChange={(v) => setFormData((p) => ({ ...p, title: v }))} placeholder="Bilik Selesa di Bangi" />
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Kategori</label>
                <select value={formData.category} onChange={(e) => setFormData((p) => ({ ...p, category: e.target.value as 'bilik' | 'rumah' }))} className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all bg-white">
                  <option value="bilik">{s.catBilikIcon} {s.catBilikName}</option><option value="rumah">{s.catRumahIcon} {s.catRumahName}</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Harga (RM/bulan)" value={String(formData.price)} onChange={(v) => setFormData((p) => ({ ...p, price: parseInt(v) || 0 }))} type="number" placeholder="500" />
              <Field label="Lokasi" value={formData.location} onChange={(v) => setFormData((p) => ({ ...p, location: v }))} placeholder="Bangi, Selangor" />
            </div>
            <Field label="Penerangan" value={formData.description} onChange={(v) => setFormData((p) => ({ ...p, description: v }))} placeholder="Terangkan unit..." rows={3} />
            <Field label="Kemudahan (koma)" value={formData.features} onChange={(v) => setFormData((p) => ({ ...p, features: v }))} placeholder="WiFi, Aircond, Katil" />
            <Field label="No. Telefon" value={formData.contact} onChange={(v) => setFormData((p) => ({ ...p, contact: v }))} placeholder="012-345 6789" />
            <div className="flex items-center gap-3 pt-2">
              <button onClick={handleSave} className="flex-1 bg-emerald-600 text-white py-3 rounded-2xl font-bold text-lg hover:bg-emerald-700 transition-colors shadow-lg">💾 Simpan</button>
              <button onClick={() => setShowForm(false)} className="px-6 py-3 bg-gray-100 text-gray-700 rounded-2xl font-bold hover:bg-gray-200 transition-colors">Batal</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ===== MAIN ADMIN PANEL =====
  return (
    <div className="fixed inset-0 z-[110] flex items-start justify-center p-4 pt-4 sm:pt-8 overflow-y-auto">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-3xl max-w-5xl w-full shadow-2xl mb-8 animate-scale-in">
        {/* Header with Role Badge */}
        <div className="sticky top-0 z-10 bg-white rounded-t-3xl border-b border-gray-200 px-6 sm:px-8 pt-6 pb-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div>
                <h2 className="text-2xl font-extrabold text-gray-900">⚙️ Panel Admin</h2>
                <p className="text-gray-500 text-sm mt-0.5">
                  {isMainAdmin ? 'Kawal penuh segalanya' : 'Urus senarai sewa sahaja'}
                </p>
              </div>
              <span className={`px-3 py-1.5 rounded-full text-xs font-extrabold ${
                isMainAdmin ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-blue-100 text-blue-800 border border-blue-300'
              }`}>
                {isMainAdmin ? '👑 Main Admin' : '📋 Admin'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={handleLogout} className="text-xs bg-red-100 text-red-700 px-3 py-1.5 rounded-lg font-bold hover:bg-red-200 transition-colors">🚪 Log Keluar</button>
              <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full"><svg className="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
            </div>
          </div>
          {/* Tabs */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1 scrollbar-hide">
            {visibleTabs.map((tab) => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex-shrink-0 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                  activeTab === tab.id ? 'bg-emerald-600 text-white shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}>
                {tab.icon} {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="px-6 sm:px-8 py-6 space-y-6 max-h-[65vh] overflow-y-auto">

          {/* ===== BRANDING ===== */}
          {activeTab === 'branding' && (
            <div className="space-y-5">
              <h3 className="text-lg font-extrabold text-gray-900">🏢 Merek, Logo & Identiti</h3>
              <ImageUpload label="Gambar Logo (menggantikan emoji)" value={s.logoImage} onUpload={handleSettingImageUpload('logoImage')} onRemove={() => set('logoImage', '')} previewClass="w-24 h-24" />
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Field label="Emoji Logo (jika tiada gambar)" value={s.logoEmoji} onChange={(v) => set('logoEmoji', v)} placeholder="🏡" />
                <Field label="Nama Laman" value={s.siteName} onChange={(v) => set('siteName', v)} placeholder="RumahSewa" />
                <Field label="Tagline" value={s.siteTagline} onChange={(v) => set('siteTagline', v)} placeholder="Cari Perumahan Ideal Anda" />
              </div>
              <div className="bg-gray-50 rounded-2xl p-5 border border-gray-200">
                <p className="text-xs font-bold text-gray-400 uppercase mb-3">Pratonton Header:</p>
                <div className="flex items-center gap-3">
                  {s.logoImage ? (
                    <img src={s.logoImage} alt="Logo" className="w-10 h-10 object-cover rounded-lg" />
                  ) : (
                    <span className="text-3xl">{s.logoEmoji}</span>
                  )}
                  <div>
                    <div className="text-xl font-bold text-gray-900">{s.siteName}</div>
                    <div className="text-xs text-gray-500">{s.siteTagline}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ===== COLORS ===== */}
          {activeTab === 'colors' && (
            <div className="space-y-5">
              <h3 className="text-lg font-extrabold text-gray-900">🎨 Warna & Tema Visual</h3>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">Pilih Tema Sedia Ada</label>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  {themePresets.map((preset) => (
                    <button key={preset.color} onClick={() => set('primaryColor', preset.color)}
                      className={`p-3 rounded-2xl border-2 transition-all text-center ${s.primaryColor === preset.color ? 'border-gray-900 shadow-lg scale-105' : 'border-gray-200 hover:border-gray-400'}`}>
                      <div className="w-8 h-8 rounded-full mx-auto mb-1.5 shadow-inner" style={{ backgroundColor: preset.color }} />
                      <div className="text-xs font-bold text-gray-700">{preset.emoji} {preset.name}</div>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">Warna Kustom (Hex)</label>
                <div className="flex items-center gap-3">
                  <input type="color" value={s.primaryColor} onChange={(e) => set('primaryColor', e.target.value)} className="w-12 h-12 rounded-xl border-2 border-gray-200 cursor-pointer" />
                  <input type="text" value={s.primaryColor} onChange={(e) => set('primaryColor', e.target.value)} className="flex-1 px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none font-mono text-gray-900" />
                </div>
              </div>
              <div className="bg-gray-50 rounded-2xl p-5 border border-gray-200 space-y-3">
                <p className="text-xs font-bold text-gray-400 uppercase">Pratonton Palet Warna:</p>
                <div className="grid grid-cols-5 gap-2">
                  {[{ c: adjustColor(s.primaryColor, 180), l: 'Cerah' }, { c: colorWithAlpha(s.primaryColor, 0.15), l: 'Latar' }, { c: s.primaryColor, l: 'Utama' }, { c: adjustColor(s.primaryColor, -30), l: 'Gelap' }, { c: adjustColor(s.primaryColor, -80), l: 'Pekat' }].map((x, i) => (
                    <div key={i} className="text-center"><div className="h-10 rounded-xl mb-1" style={{ backgroundColor: x.c }} /><span className="text-[10px] text-gray-500">{x.l}</span></div>
                  ))}
                </div>
                <div className="flex gap-2 pt-2">
                  <button className="px-4 py-2 rounded-xl text-white font-bold text-sm" style={{ backgroundColor: s.primaryColor }}>Butang Utama</button>
                  <button className="px-4 py-2 rounded-xl font-bold text-sm border-2" style={{ borderColor: s.primaryColor, color: s.primaryColor, backgroundColor: colorWithAlpha(s.primaryColor, 0.1) }}>Butang Outline</button>
                </div>
              </div>
            </div>
          )}

          {/* ===== HERO ===== */}
          {activeTab === 'hero' && (
            <div className="space-y-5">
              <h3 className="text-lg font-extrabold text-gray-900">🖼️ Halaman Utama (Hero)</h3>
              <ImageUpload label="Gambar Latar Belakang Hero" value={s.heroBackgroundImage} onUpload={handleSettingImageUpload('heroBackgroundImage')} onRemove={() => set('heroBackgroundImage', '')} previewClass="w-full h-32" />
              <Field label="Teks Lencana (Badge)" value={s.heroBadgeText} onChange={(v) => set('heroBadgeText', v)} />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Baris Tajuk 1" value={s.heroTitleLine1} onChange={(v) => set('heroTitleLine1', v)} />
                <Field label="Baris Tajuk 2 (Berwarna)" value={s.heroTitleLine2} onChange={(v) => set('heroTitleLine2', v)} />
              </div>
              <Field label="Penerangan" value={s.heroDescription} onChange={(v) => set('heroDescription', v)} rows={3} />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Emoji Butang CTA 1" value={s.heroCtaEmoji} onChange={(v) => set('heroCtaEmoji', v)} />
                <Field label="Teks Butang CTA 1" value={s.heroCtaText} onChange={(v) => set('heroCtaText', v)} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Emoji Butang CTA 2" value={s.heroSecondaryCtaEmoji} onChange={(v) => set('heroSecondaryCtaEmoji', v)} />
                <Field label="Teks Butang CTA 2" value={s.heroSecondaryCtaText} onChange={(v) => set('heroSecondaryCtaText', v)} />
              </div>
              <div className="border-t border-gray-200 pt-4">
                <p className="text-sm font-bold text-gray-700 mb-3">Statistik Hero</p>
                <div className="grid grid-cols-3 gap-4">
                  <div><Field label="Nilai Stat 1" value={s.heroStat1Value} onChange={(v) => set('heroStat1Value', v)} /><Field label="Label Stat 1" value={s.heroStat1Label} onChange={(v) => set('heroStat1Label', v)} /></div>
                  <div><Field label="Nilai Stat 2" value={s.heroStat2Value} onChange={(v) => set('heroStat2Value', v)} /><Field label="Label Stat 2" value={s.heroStat2Label} onChange={(v) => set('heroStat2Label', v)} /></div>
                  <div><Field label="Nilai Stat 3" value={s.heroStat3Value} onChange={(v) => set('heroStat3Value', v)} /><Field label="Label Stat 3" value={s.heroStat3Label} onChange={(v) => set('heroStat3Label', v)} /></div>
                </div>
              </div>
            </div>
          )}

          {/* ===== CATEGORIES ===== */}
          {activeTab === 'categories' && (
            <div className="space-y-5">
              <h3 className="text-lg font-extrabold text-gray-900">📂 Kategori Perumahan</h3>
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-5 space-y-4">
                <p className="text-sm font-bold text-blue-900">{s.catBilikIcon} Kategori 1 — Bilik</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <Field label="Nama" value={s.catBilikName} onChange={(v) => set('catBilikName', v)} />
                  <Field label="Emoji/Ikon" value={s.catBilikIcon} onChange={(v) => set('catBilikIcon', v)} />
                  <Field label="Penerangan" value={s.catBilikDesc} onChange={(v) => set('catBilikDesc', v)} />
                </div>
              </div>
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-5 space-y-4">
                <p className="text-sm font-bold text-emerald-900">{s.catRumahIcon} Kategori 2 — Rumah</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <Field label="Nama" value={s.catRumahName} onChange={(v) => set('catRumahName', v)} />
                  <Field label="Emoji/Ikon" value={s.catRumahIcon} onChange={(v) => set('catRumahIcon', v)} />
                  <Field label="Penerangan" value={s.catRumahDesc} onChange={(v) => set('catRumahDesc', v)} />
                </div>
              </div>
            </div>
          )}

          {/* ===== CONTACT ===== */}
          {activeTab === 'contact' && (
            <div className="space-y-5">
              <h3 className="text-lg font-extrabold text-gray-900">📞 Maklumat Hubungan</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="No. Telefon (Paparan)" value={s.contactPhoneDisplay} onChange={(v) => set('contactPhoneDisplay', v)} />
                <Field label="No. Telefon (Panggilan)" value={s.contactPhone} onChange={(v) => set('contactPhone', v)} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="No. WhatsApp (Paparan)" value={s.contactWhatsapp} onChange={(v) => set('contactWhatsapp', v)} />
                <Field label="WhatsApp (International, tanpa +)" value={s.contactWhatsappInt} onChange={(v) => set('contactWhatsappInt', v)} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Alamat E-mel" value={s.contactEmail} onChange={(v) => set('contactEmail', v)} />
                <Field label="Alamat Fizikal" value={s.contactAddress} onChange={(v) => set('contactAddress', v)} />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Waktu Operasi (Isnin-Jumaat)" value={s.contactHoursWeekday} onChange={(v) => set('contactHoursWeekday', v)} />
                <Field label="Waktu Operasi (Sabtu-Ahad)" value={s.contactHoursWeekend} onChange={(v) => set('contactHoursWeekend', v)} />
              </div>
            </div>
          )}

          {/* ===== FOOTER ===== */}
          {activeTab === 'footer' && (
            <div className="space-y-5">
              <h3 className="text-lg font-extrabold text-gray-900">📄 Kandungan Footer</h3>
              <Field label="Tajuk CTA Footer" value={s.footerCtaTitle} onChange={(v) => set('footerCtaTitle', v)} />
              <Field label="Penerangan CTA Footer" value={s.footerCtaDescription} onChange={(v) => set('footerCtaDescription', v)} rows={2} />
              <Field label="Teks Butang CTA" value={s.footerCtaButtonText} onChange={(v) => set('footerCtaButtonText', v)} />
              <Field label="Penerangan Syarikat" value={s.footerDescription} onChange={(v) => set('footerDescription', v)} rows={3} />
              <Field label="Teks Hak Cipta" value={s.footerCopyright} onChange={(v) => set('footerCopyright', v)} />
            </div>
          )}

          {/* ===== TENANT FORM ===== */}
          {activeTab === 'tenant' && (
            <div className="space-y-5">
              <h3 className="text-lg font-extrabold text-gray-900">📝 Borang Pendaftaran Penyewa</h3>
              <Field label="Tajuk Borang" value={s.tenantFormHeading} onChange={(v) => set('tenantFormHeading', v)} />
              <Field label="Subtajuk Borang" value={s.tenantFormSubheading} onChange={(v) => set('tenantFormSubheading', v)} />
              <Field label={'Tajuk Seksyen "Mengapa Daftar"'} value={s.tenantFormWhyTitle} onChange={(v) => set('tenantFormWhyTitle', v)} />
              <Field label="Penerangan Faedah" value={s.tenantFormWhyDesc} onChange={(v) => set('tenantFormWhyDesc', v)} rows={3} />
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Field label="Faedah 1" value={s.tenantFormBenefit1} onChange={(v) => set('tenantFormBenefit1', v)} />
                <Field label="Faedah 2" value={s.tenantFormBenefit2} onChange={(v) => set('tenantFormBenefit2', v)} />
                <Field label="Faedah 3" value={s.tenantFormBenefit3} onChange={(v) => set('tenantFormBenefit3', v)} />
              </div>
            </div>
          )}

          {/* ===== LISTINGS (Both roles can access) ===== */}
          {activeTab === 'listings' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-extrabold text-gray-900">🏠 Senarai Unit ({listings.length})</h3>
                <div className="flex gap-2">
                  <button onClick={startAdd} className="inline-flex items-center gap-1.5 bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-emerald-700 transition-colors">➕ Tambah</button>
                  {isMainAdmin && (
                    <button onClick={() => { if (confirm('Set semula listing?')) resetListings(); }} className="inline-flex items-center gap-1.5 bg-amber-100 text-amber-700 px-4 py-2 rounded-xl font-bold text-sm hover:bg-amber-200 transition-colors">🔄 Reset</button>
                  )}
                </div>
              </div>
              <div className="space-y-3">
                {listings.map((listing) => (
                  <div key={listing.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors">
                    <img src={listing.image} alt={listing.title} className="w-16 h-16 object-cover rounded-xl border border-gray-200 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${listing.category === 'bilik' ? 'bg-blue-100 text-blue-700' : 'bg-emerald-100 text-emerald-700'}`}>
                          {listing.category === 'bilik' ? `${s.catBilikIcon} ${s.catBilikName}` : `${s.catRumahIcon} ${s.catRumahName}`}
                        </span>
                        <span className="font-extrabold text-emerald-600 text-sm">RM{listing.price.toLocaleString()}/bulan</span>
                      </div>
                      <h4 className="font-bold text-gray-900 text-sm truncate">{listing.title}</h4>
                      <p className="text-xs text-gray-500 truncate">📍 {listing.location} · 📞 {listing.contact}</p>
                    </div>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      <button onClick={() => startEdit(listing)} className="p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm">✏️</button>
                      <button onClick={() => { if (confirm('Padam?')) deleteListing(listing.id); }} className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors text-sm">🗑️</button>
                    </div>
                  </div>
                ))}
                {listings.length === 0 && <div className="text-center py-8 text-gray-400">Tiada listing.</div>}
              </div>
            </div>
          )}

          {/* ===== TENANTS ===== */}
          {activeTab === 'tenants' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-extrabold text-gray-900">👥 Senarai Penyewa Berdaftar ({tenants.length})</h3>
                {!isMainAdmin && (
                  <span className="text-xs bg-blue-100 text-blue-700 px-3 py-1.5 rounded-full font-bold border border-blue-200">👁️ Mod Semakan Sahaja</span>
                )}
              </div>
              {!isMainAdmin && (
                <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-sm text-blue-800 font-medium">
                  📋 Anda hanya boleh melihat senarai penyewa untuk semakan. Hanya <strong>Main Admin</strong> boleh memadam rekod penyewa.
                </div>
              )}
              {tenants.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-2xl"><div className="text-4xl mb-2">👥</div><p className="text-gray-400">Tiada pendaftaran penyewa lagi.</p></div>
              ) : (
                <div className="space-y-3">
                  {tenants.map((t) => (
                    <div key={t.id} className="p-4 bg-gray-50 rounded-2xl relative">
                      {isMainAdmin && (
                        <button onClick={() => { if (confirm('Padam rekod penyewa ini?')) deleteTenant(t.id); }} className="absolute top-3 right-3 p-1.5 bg-red-50 text-red-500 rounded-lg hover:bg-red-100 text-xs">🗑️</button>
                      )}
                      <div className={isMainAdmin ? 'pr-10' : ''}>
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="font-bold text-gray-900">{t.name}</span>
                          <span className="text-xs text-gray-400">({t.createdAt})</span>
                          {t.targetListing && <span className="text-xs font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">🎯 {t.targetListing}</span>}
                          <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${t.preferredCategory === 'bilik' ? 'bg-blue-100 text-blue-700' : t.preferredCategory === 'rumah' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-700'}`}>
                            {t.preferredCategory === 'bilik' ? '🛏️ Bilik' : t.preferredCategory === 'rumah' ? '🏠 Rumah' : '🔍 Mana-mana'}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600">📞 {t.phone} {t.email && `· 📧 ${t.email}`}</p>
                        <p className="text-xs text-gray-600">💰 RM{t.budget}/bulan · 📅 Masuk: {t.moveInDate}</p>
                        {t.notes && <p className="text-xs text-amber-700 mt-1 bg-amber-50 rounded-lg p-2 border border-amber-100">💬 {t.notes}</p>}
                        <div className="flex gap-2 mt-2">
                          <a href={`https://wa.me/${t.phone.replace(/[^0-9]/g, '')}`} target="_blank" rel="noopener noreferrer" className="text-xs bg-emerald-600 text-white px-3 py-1 rounded-lg font-bold hover:bg-emerald-700">💬 WhatsApp</a>
                          <a href={`tel:${t.phone}`} className="text-xs bg-gray-200 text-gray-800 px-3 py-1 rounded-lg font-bold hover:bg-gray-300">📞 Hubungi</a>
                          {t.email && <a href={`mailto:${t.email}`} className="text-xs bg-amber-100 text-amber-800 px-3 py-1 rounded-lg font-bold hover:bg-amber-200">📧 E-mel</a>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ===== SECURITY (Main Admin Only) ===== */}
          {activeTab === 'security' && (
            <div className="space-y-5">
              <h3 className="text-lg font-extrabold text-gray-900">🔒 Keselamatan & Kata Laluan</h3>
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 space-y-4">
                <p className="text-sm font-bold text-amber-900">👑 Kata Laluan Main Admin</p>
                <Field label="Kata Laluan Main Admin" value={s.mainAdminPassword} onChange={(v) => set('mainAdminPassword', v)} placeholder="Hisyam97@" />
                <p className="text-xs text-amber-700">Kata laluan ini memberikan akses penuh kepada semua tetapan laman web, reka bentuk, maklumat, senarai & keselamatan.</p>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-5 space-y-4">
                <p className="text-sm font-bold text-blue-900">📋 Kata Laluan Admin (Kakitangan)</p>
                <Field label="Kata Laluan Admin" value={s.staffAdminPassword} onChange={(v) => set('staffAdminPassword', v)} placeholder="Admin" />
                <p className="text-xs text-blue-700">Admin hanya boleh menambah, mengubah & memadam senarai sewa serta melihat senarai penyewa untuk semakan. Tiada akses kepada tetapan lain.</p>
              </div>
              <div className="bg-red-50 border border-red-200 rounded-2xl p-5 space-y-4">
                <p className="text-sm font-bold text-red-900">⚠️ Zon Berbahaya</p>
                <p className="text-xs text-red-700 mb-3">Tindakan ini tidak boleh dibatalkan.</p>
                <div className="flex gap-3">
                  <button onClick={() => { if (confirm('Set semula SEMUA tetapan ke asal?')) resetSettings(); }} className="bg-amber-100 text-amber-800 px-4 py-2 rounded-xl font-bold text-sm hover:bg-amber-200 transition-colors">🔄 Reset Tetapan</button>
                  <button onClick={() => { if (confirm('Set semula SENARAI ke asal?')) resetListings(); }} className="bg-amber-100 text-amber-800 px-4 py-2 rounded-xl font-bold text-sm hover:bg-amber-200 transition-colors">🏠 Reset Senarai</button>
                  <button onClick={() => { if (confirm('PADAM SEMUA DATA dan kembalikan ke asal?')) resetAll(); }} className="bg-red-100 text-red-800 px-4 py-2 rounded-xl font-bold text-sm hover:bg-red-200 transition-colors">💥 Reset Semua</button>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t border-gray-200 px-6 sm:px-8 py-4 rounded-b-3xl flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={`text-xs px-2 py-1 rounded-full font-bold ${isMainAdmin ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'}`}>
              {isMainAdmin ? '👑 Main Admin' : '📋 Admin'}
            </span>
          </div>
          <button onClick={onClose} className="bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold hover:bg-emerald-700 transition-colors shadow-lg">✅ Selesai</button>
        </div>
      </div>
    </div>
  );
}
