import { useListingsStore } from '../store';

interface Props {
  onTenantRegisterClick: () => void;
}

export default function Hero({ onTenantRegisterClick }: Props) {
  const { settings: s } = useListingsStore();
  const bgImage = s.heroBackgroundImage || '/images/hero-bg.jpg';

  return (
    <section id="utama" className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img src={bgImage} alt="Latar Belakang" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />
      </div>

      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md border border-white/30 rounded-full px-5 py-2 mb-8">
          <span className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: 'var(--theme-primary)' }} />
          <span className="text-white/90 text-sm font-medium">{s.heroBadgeText}</span>
        </div>

        <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold text-white leading-tight mb-6">
          {s.heroTitleLine1}
          <br />
          <span className="text-theme-gradient">{s.heroTitleLine2}</span>
        </h1>

        <p className="text-lg sm:text-xl text-white/80 max-w-2xl mx-auto mb-10 leading-relaxed">
          {s.heroDescription}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a href="#senarai"
            className="w-full sm:w-auto bg-theme text-white px-8 py-4 rounded-2xl font-bold text-lg hover-bg-theme transition-all shadow-2xl hover:-translate-y-0.5"
            style={{ boxShadow: `0 25px 50px -12px rgba(0,0,0,0.4)` }}>
            {s.heroCtaEmoji} {s.heroCtaText}
          </a>
          <button onClick={onTenantRegisterClick}
            className="w-full sm:w-auto bg-white/15 backdrop-blur-md text-white border border-white/30 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-white/25 transition-all hover:-translate-y-0.5">
            {s.heroSecondaryCtaEmoji} {s.heroSecondaryCtaText}
          </button>
        </div>

        <div className="grid grid-cols-3 gap-6 mt-16 max-w-lg mx-auto">
          <div className="text-center">
            <div className="text-3xl font-extrabold text-white">{s.heroStat1Value}</div>
            <div className="text-white/60 text-sm mt-1">{s.heroStat1Label}</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-extrabold text-white">{s.heroStat2Value}</div>
            <div className="text-white/60 text-sm mt-1">{s.heroStat2Label}</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-extrabold text-white">{s.heroStat3Value}</div>
            <div className="text-white/60 text-sm mt-1">{s.heroStat3Label}</div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <svg className="w-6 h-6 text-white/60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
}
