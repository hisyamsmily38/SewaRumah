import { useListingsStore } from '../store';

interface Props {
  onClose: () => void;
}

export default function ContactModal({ onClose }: Props) {
  const { settings: s } = useListingsStore();

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-3xl max-w-lg w-full shadow-2xl p-6 sm:p-8 animate-scale-in">
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <span className="text-3xl">📞</span>
            <div>
              <h2 className="text-2xl font-extrabold text-gray-900">Hubungi Kami</h2>
              <p className="text-gray-500 text-xs mt-0.5">Kami sedia membantu anda</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <svg className="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <p className="text-gray-600 text-sm mb-6 leading-relaxed">
          Ada pertanyaan mengenai bilik sewa, rumah sewa, atau ingin menyenaraikan hartanah anda? Pilih saluran komunikasi pilihan anda:
        </p>

        <div className="space-y-4 mb-6">
          {/* WhatsApp */}
          <a href={`https://wa.me/${s.contactWhatsappInt}?text=Hai%20${s.siteName},%20saya%20ingin%20bertanya%20mengenai%20perumahan/bilik%20sewa.`} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-4 p-4 bg-theme-50 border border-theme-200 rounded-2xl hover:bg-theme-100 transition-all group">
            <div className="w-12 h-12 bg-theme text-white rounded-xl flex items-center justify-center text-2xl shadow-md group-hover:scale-105 transition-transform">💬</div>
            <div className="flex-1">
              <div className="text-xs font-bold text-theme-dark uppercase tracking-wider mb-0.5">Sembang WhatsApp (Pantas)</div>
              <div className="text-lg font-extrabold text-gray-900">+{s.contactWhatsappInt}</div>
              <div className="text-xs text-theme mt-0.5">Klik untuk buka WhatsApp</div>
            </div>
            <svg className="w-5 h-5 text-theme mr-2 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>

          {/* Phone */}
          <a href={`tel:${s.contactPhone}`} className="flex items-center gap-4 p-4 bg-blue-50 border border-blue-200 rounded-2xl hover:bg-blue-100 transition-all group">
            <div className="w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center text-2xl shadow-md group-hover:scale-105 transition-transform">📱</div>
            <div className="flex-1">
              <div className="text-xs font-bold text-blue-800 uppercase tracking-wider mb-0.5">Panggilan Telefon</div>
              <div className="text-lg font-extrabold text-blue-950">{s.contactPhoneDisplay}</div>
              <div className="text-xs text-blue-700 mt-0.5">Perkhidmatan pelanggan</div>
            </div>
            <svg className="w-5 h-5 text-blue-600 mr-2 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>

          {/* Email */}
          <a href={`mailto:${s.contactEmail}`} className="flex items-center gap-4 p-4 bg-amber-50 border border-amber-200 rounded-2xl hover:bg-amber-100 transition-all group">
            <div className="w-12 h-12 bg-amber-600 text-white rounded-xl flex items-center justify-center text-2xl shadow-md group-hover:scale-105 transition-transform">📧</div>
            <div className="flex-1">
              <div className="text-xs font-bold text-amber-800 uppercase tracking-wider mb-0.5">E-Mel Rasmi</div>
              <div className="text-lg font-extrabold text-amber-950">{s.contactEmail}</div>
              <div className="text-xs text-amber-700 mt-0.5">Maklum balas dalam 24 jam</div>
            </div>
            <svg className="w-5 h-5 text-amber-600 mr-2 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>

        <div className="bg-gray-50 rounded-2xl p-4 text-center text-xs text-gray-500 mb-6 border border-gray-100">
          <span className="font-bold text-gray-700 block mb-1">⏰ Waktu Operasi:</span>
          Isnin - Jumaat: {s.contactHoursWeekday}<br />
          Sabtu & Ahad: {s.contactHoursWeekend}
        </div>

        <button onClick={onClose} className="w-full py-3.5 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold rounded-2xl transition-colors">Tutup</button>
      </div>
    </div>
  );
}
