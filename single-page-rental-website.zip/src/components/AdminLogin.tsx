import { useState } from 'react';
import { useListingsStore, AdminRole } from '../store';

interface Props {
  onClose: () => void;
  onLoginSuccess: () => void;
}

export default function AdminLogin({ onClose, onLoginSuccess }: Props) {
  const { settings, loginAdmin } = useListingsStore();
  const [selectedRole, setSelectedRole] = useState<AdminRole>(null);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = () => {
    if (!selectedRole) {
      setError('Sila pilih peranan anda terlebih dahulu.');
      return;
    }
    if (!password) {
      setError('Sila masukkan kata laluan.');
      return;
    }

    if (selectedRole === 'main') {
      if (password === settings.mainAdminPassword) {
        loginAdmin('main');
        onLoginSuccess();
      } else {
        setError('Kata laluan Main Admin salah.');
      }
    } else if (selectedRole === 'staff') {
      if (password === settings.staffAdminPassword) {
        loginAdmin('staff');
        onLoginSuccess();
      } else {
        setError('Kata laluan Admin salah.');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[130] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in" onClick={onClose} />
      <div className="relative bg-white rounded-3xl max-w-md w-full shadow-2xl p-6 sm:p-8 animate-scale-in">
        {/* Close */}
        <button onClick={onClose} className="absolute top-4 right-4 p-2 hover:bg-gray-100 rounded-full transition-colors">
          <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Header */}
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🔐</div>
          <h2 className="text-2xl font-extrabold text-gray-900">Log Masuk Admin</h2>
          <p className="text-gray-500 text-sm mt-2">Pilih peranan dan masukkan kata laluan anda</p>
        </div>

        {/* Role Selection */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <button
            onClick={() => { setSelectedRole('main'); setError(''); }}
            className={`p-5 rounded-2xl border-2 text-center transition-all ${
              selectedRole === 'main'
                ? 'border-amber-500 bg-amber-50 shadow-lg'
                : 'border-gray-200 bg-white hover:border-amber-300'
            }`}
          >
            <div className="text-3xl mb-2">👑</div>
            <div className="font-extrabold text-gray-900 text-sm">Main Admin</div>
            <div className="text-[10px] text-gray-500 mt-1.5 leading-tight">Kawal penuh segalanya — reka bentuk, warna, maklumat, gambar, senarai, kata laluan</div>
          </button>
          <button
            onClick={() => { setSelectedRole('staff'); setError(''); }}
            className={`p-5 rounded-2xl border-2 text-center transition-all ${
              selectedRole === 'staff'
                ? 'border-blue-500 bg-blue-50 shadow-lg'
                : 'border-gray-200 bg-white hover:border-blue-300'
            }`}
          >
            <div className="text-3xl mb-2">📋</div>
            <div className="font-extrabold text-gray-900 text-sm">Admin</div>
            <div className="text-[10px] text-gray-500 mt-1.5 leading-tight">Tugas & paparan terhad — hanya urus senarai sewa & semak penyewa</div>
          </button>
        </div>

        {/* Role Description */}
        {selectedRole && (
          <div className={`mb-5 p-4 rounded-xl text-xs font-medium border leading-relaxed ${
            selectedRole === 'main'
              ? 'bg-amber-50 text-amber-900 border-amber-200'
              : 'bg-blue-50 text-blue-900 border-blue-200'
          }`}>
            {selectedRole === 'main' ? (
              <>
                <strong>👑 Main Admin</strong> mempunyai akses penuh untuk mengubah:
                <ul className="mt-1.5 ml-4 list-disc space-y-0.5">
                  <li>Reka bentuk, warna & tema visual</li>
                  <li>Gambar logo & latar belakang hero</li>
                  <li>Maklumat laman, hero, kategori, hubungan & footer</li>
                  <li>Borang pendaftaran penyewa</li>
                  <li>Senarai unit (tambah, edit, padam)</li>
                  <li>Data penyewa (semak & padam)</li>
                  <li>Kata laluan admin</li>
                </ul>
              </>
            ) : (
              <>
                <strong>📋 Admin</strong> hanya dibenarkan untuk:
                <ul className="mt-1.5 ml-4 list-disc space-y-0.5">
                  <li>Menambah, mengubah & memadam senarai sewa (unit bilik/rumah)</li>
                  <li>Melihat senarai penyewa berdaftar untuk semakan (tidak boleh memadam)</li>
                </ul>
                <p className="mt-1.5 font-bold">Akses kepada tetapan lain adalah tidak dibenarkan.</p>
              </>
            )}
          </div>
        )}

        {/* Password */}
        <div className="mb-5">
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">Kata Laluan</label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(''); }}
              onKeyDown={(e) => { if (e.key === 'Enter') handleLogin(); }}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition-all pr-12 text-gray-900"
              placeholder="Masukkan kata laluan..."
              autoComplete="off"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" /></svg>
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
              )}
            </button>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 text-sm font-medium rounded-xl border border-red-200 flex items-center gap-2">
            <span>⚠️</span> {error}
          </div>
        )}

        {/* Login Button */}
        <button
          onClick={handleLogin}
          disabled={!selectedRole || !password}
          className={`w-full py-3.5 rounded-2xl font-bold text-lg transition-all shadow-lg mb-3 ${
            selectedRole && password
              ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-200 cursor-pointer'
              : 'bg-gray-200 text-gray-400 shadow-none cursor-not-allowed'
          }`}
        >
          🔓 Log Masuk
        </button>

        <button onClick={onClose} className="w-full py-2.5 text-gray-500 hover:text-gray-700 text-sm font-medium transition-colors">
          Batal
        </button>
      </div>
    </div>
  );
}
