import { useState } from 'react';
import { useListingsStore } from '../store';

interface Props {
  initialListingTitle?: string;
  onClose: () => void;
}

export default function TenantForm({ initialListingTitle, onClose }: Props) {
  const { addTenant, settings: s } = useListingsStore();
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '', phone: '', email: '',
    preferredCategory: (initialListingTitle ? (initialListingTitle.toLowerCase().includes('rumah') ? 'rumah' : 'bilik') : 'mana-mana') as 'bilik' | 'rumah' | 'mana-mana',
    budget: '', moveInDate: '', notes: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) { alert('Sila isi nama dan nombor telefon.'); return; }
    addTenant({
      name: formData.name, phone: formData.phone, email: formData.email,
      preferredCategory: formData.preferredCategory,
      budget: parseFloat(formData.budget) || 0,
      moveInDate: formData.moveInDate || 'Akan dimaklumkan',
      notes: formData.notes,
      targetListing: initialListingTitle,
    });
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
        <div className="relative bg-white rounded-3xl max-w-md w-full shadow-2xl p-8 text-center animate-scale-in">
          <div className="text-6xl mb-4">🎉</div>
          <h2 className="text-2xl font-extrabold text-gray-900 mb-2">Pendaftaran Berjaya!</h2>
          <p className="text-gray-600 mb-6 leading-relaxed">Terima kasih! Permohonan anda telah direkodkan. Pihak {s.siteName} akan menghubungi anda melalui WhatsApp/telefon.</p>
          <div className="bg-theme-50 rounded-2xl p-4 text-xs font-medium mb-6 text-left space-y-1.5 border border-theme-200" style={{ color: 'var(--theme-primary-dark)' }}>
            <div className="font-bold text-center mb-1" style={{ color: 'var(--theme-primary-900)' }}>📌 Proses Seterusnya:</div>
            <p>1. <strong>Pengesahan:</strong> Kami akan menyemak lokasi dan bajet pilihan anda.</p>
            <p>2. <strong>Hubungan:</strong> Anda akan menerima mesej WhatsApp dalam 1-24 jam.</p>
            <p>3. <strong>Tinjauan:</strong> Temujanji viewing unit akan diaturkan percuma.</p>
          </div>
          <button onClick={onClose} className="w-full bg-theme text-white py-3.5 rounded-2xl font-bold text-lg hover-bg-theme transition-colors shadow-theme">Selesai & Tutup</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[120] flex items-start justify-center p-4 pt-8 sm:pt-12 overflow-y-auto">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-white rounded-3xl max-w-xl w-full shadow-2xl p-6 sm:p-8 mb-8 animate-scale-in">
        <div className="flex items-start sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-gray-100">
          <div>
            <span className="inline-block bg-theme-100 text-theme-dark text-xs font-extrabold px-3 py-1 rounded-full mb-2">
              📋 {initialListingTitle ? 'PERMOHONAN SEWA UNIT' : 'SISTEM PADANAN PENYEWA'}
            </span>
            <h2 className="text-2xl font-extrabold text-gray-900">{initialListingTitle ? '🏡 Borang Permohonan Unit' : `📝 ${s.tenantFormHeading}`}</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors flex-shrink-0">
            <svg className="w-6 h-6 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {!initialListingTitle ? (
          <div className="bg-theme-50 border border-theme-200 rounded-2xl p-5 mb-6 text-gray-700 text-sm">
            <h4 className="font-extrabold text-base mb-2 flex items-center gap-2" style={{ color: 'var(--theme-primary-900)' }}>
              <span>💡</span> {s.tenantFormWhyTitle}
            </h4>
            <p className="mb-4 text-gray-600 leading-relaxed">{s.tenantFormWhyDesc}</p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-theme-200 text-xs">
              <div className="flex items-center gap-2 font-bold" style={{ color: 'var(--theme-primary-dark)' }}><span className="text-theme">✓</span> {s.tenantFormBenefit1}</div>
              <div className="flex items-center gap-2 font-bold" style={{ color: 'var(--theme-primary-dark)' }}><span className="text-theme">✓</span> {s.tenantFormBenefit2}</div>
              <div className="flex items-center gap-2 font-bold" style={{ color: 'var(--theme-primary-dark)' }}><span className="text-theme">✓</span> {s.tenantFormBenefit3}</div>
            </div>
          </div>
        ) : (
          <div className="bg-theme-50 border border-theme-200 rounded-2xl p-4 mb-6">
            <span className="text-xs font-bold uppercase tracking-wider block mb-1" style={{ color: 'var(--theme-primary-dark)' }}>Anda memohon untuk menyewa:</span>
            <span className="font-extrabold text-gray-900 text-lg flex items-center gap-1.5"><span>📌</span> {initialListingTitle}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Nama Penuh *</label>
              <input type="text" required value={formData.name} onChange={(e) => setFormData((p) => ({ ...p, name: e.target.value }))}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 ring-theme focus:border-transparent outline-none transition-all text-gray-900" placeholder="Ahmad bin Abu Bakar" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">No. Telefon / WhatsApp *</label>
              <input type="text" required value={formData.phone} onChange={(e) => setFormData((p) => ({ ...p, phone: e.target.value }))}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 ring-theme focus:border-transparent outline-none transition-all text-gray-900" placeholder="012-345 6789" />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">E-mel</label>
              <input type="email" value={formData.email} onChange={(e) => setFormData((p) => ({ ...p, email: e.target.value }))}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 ring-theme focus:border-transparent outline-none transition-all text-gray-900" placeholder="email@domain.com" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Kategori Perumahan</label>
              <select value={formData.preferredCategory} onChange={(e) => setFormData((p) => ({ ...p, preferredCategory: e.target.value as 'bilik' | 'rumah' | 'mana-mana' }))}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 ring-theme focus:border-transparent outline-none transition-all text-gray-900 bg-white">
                <option value="bilik">{s.catBilikIcon} {s.catBilikName}</option>
                <option value="rumah">{s.catRumahIcon} {s.catRumahName}</option>
                <option value="mana-mana">🔍 Mana-mana</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Bajet Bulanan (RM)</label>
              <input type="number" value={formData.budget} onChange={(e) => setFormData((p) => ({ ...p, budget: e.target.value }))}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 ring-theme focus:border-transparent outline-none transition-all text-gray-900" placeholder="600" />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1.5">Tarikh Kemasukan Dijangka</label>
              <input type="date" value={formData.moveInDate} onChange={(e) => setFormData((p) => ({ ...p, moveInDate: e.target.value }))}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 ring-theme focus:border-transparent outline-none transition-all text-gray-900 bg-white" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">Catatan Tambahan</label>
            <textarea value={formData.notes} onChange={(e) => setFormData((p) => ({ ...p, notes: e.target.value }))} rows={3}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 ring-theme focus:border-transparent outline-none transition-all resize-none text-gray-900"
              placeholder="Contoh: Berdekatan LRT, perlukan parkir, fully-furnished..." />
          </div>
          <div className="pt-2 flex items-center gap-3">
            <button type="submit" className="flex-1 bg-theme text-white py-3.5 rounded-2xl font-bold text-lg hover-bg-theme transition-colors shadow-theme flex items-center justify-center gap-2">
              🚀 Hantar Permohonan
            </button>
            <button type="button" onClick={onClose} className="px-6 py-3.5 bg-gray-100 text-gray-700 rounded-2xl font-bold hover:bg-gray-200 transition-colors">Batal</button>
          </div>
        </form>
      </div>
    </div>
  );
}
