import { useState } from 'react';
import { useListingsStore } from '../store';

interface Props {
  onAdminClick: () => void;
  onTenantRegisterClick: () => void;
  onContactClick: () => void;
}

export default function Header({ onAdminClick, onTenantRegisterClick, onContactClick }: Props) {
  const { settings: s } = useListingsStore();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            {s.logoImage ? (
              <img src={s.logoImage} alt={s.siteName} className="w-10 h-10 object-cover rounded-lg" />
            ) : (
              <span className="text-2xl">{s.logoEmoji}</span>
            )}
            <div>
              <h1 className="text-xl font-bold text-gray-900 leading-tight">{s.siteName}</h1>
              <p className="text-[10px] text-gray-500 leading-none -mt-0.5">{s.siteTagline}</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <a href="#utama" className="text-gray-700 hover:text-theme font-medium transition-colors">Utama</a>
            <a href="#kategori" className="text-gray-700 hover:text-theme font-medium transition-colors">Kategori</a>
            <a href="#senarai" className="text-gray-700 hover:text-theme font-medium transition-colors">Senarai</a>
            <button onClick={onTenantRegisterClick}
              className="inline-flex items-center gap-1.5 bg-theme-50 text-theme-dark px-4 py-2 rounded-full font-semibold text-sm hover:bg-theme-100 transition-colors border border-theme-200">
              📝 Daftar Penyewa
            </button>
            <button onClick={onAdminClick}
              className="inline-flex items-center gap-1.5 bg-amber-100 text-amber-700 px-4 py-2 rounded-full font-semibold text-sm hover:bg-amber-200 transition-colors">
              ⚙️ Admin
            </button>
            <button onClick={onContactClick}
              className="bg-theme text-white px-5 py-2 rounded-full font-medium hover-bg-theme transition-colors shadow-theme inline-flex items-center gap-1.5">
              <span>📞</span> Hubungi Kami
            </button>
          </nav>

          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors">
            <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {menuOpen ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
        </div>

        {menuOpen && (
          <nav className="md:hidden pb-4 border-t border-gray-100 pt-3 space-y-2">
            <a href="#utama" onClick={() => setMenuOpen(false)} className="block px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-50 font-medium">Utama</a>
            <a href="#kategori" onClick={() => setMenuOpen(false)} className="block px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-50 font-medium">Kategori</a>
            <a href="#senarai" onClick={() => setMenuOpen(false)} className="block px-3 py-2 rounded-lg text-gray-700 hover:bg-gray-50 font-medium">Senarai</a>
            <button onClick={() => { setMenuOpen(false); onTenantRegisterClick(); }}
              className="block w-full text-left px-3 py-2 rounded-lg bg-theme-50 text-theme-dark font-medium">📝 Daftar Penyewa</button>
            <button onClick={() => { setMenuOpen(false); onAdminClick(); }}
              className="block w-full text-left px-3 py-2 rounded-lg bg-amber-100 text-amber-700 font-medium">⚙️ Admin</button>
            <button onClick={() => { setMenuOpen(false); onContactClick(); }}
              className="block w-full px-3 py-2.5 rounded-lg bg-theme text-white text-center font-medium">📞 Hubungi Kami</button>
          </nav>
        )}
      </div>
    </header>
  );
}
