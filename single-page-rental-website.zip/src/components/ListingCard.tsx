import { Listing } from '../data/listings';
import { useListingsStore } from '../store';

interface Props {
  listing: Listing;
  onClick: () => void;
}

export default function ListingCard({ listing, onClick }: Props) {
  const { settings: s } = useListingsStore();

  return (
    <div onClick={onClick}
      className="group bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 cursor-pointer">
      <div className="relative overflow-hidden aspect-[4/3]">
        <img src={listing.image} alt={listing.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
        <div className="absolute top-4 left-4">
          <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold backdrop-blur-md ${
            listing.category === 'bilik' ? 'bg-blue-500/90 text-white' : 'bg-theme text-white'
          }`}>
            {listing.category === 'bilik' ? s.catBilikIcon : s.catRumahIcon} {listing.category === 'bilik' ? s.catBilikName : s.catRumahName}
          </span>
        </div>
        <div className="absolute bottom-4 right-4">
          <span className="bg-white/95 backdrop-blur-md text-gray-900 font-extrabold text-lg px-4 py-2 rounded-2xl shadow-lg">
            RM{listing.price.toLocaleString()}<span className="text-sm font-medium text-gray-500">/bulan</span>
          </span>
        </div>
      </div>
      <div className="p-5">
        <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-theme transition-colors line-clamp-1">{listing.title}</h3>
        <div className="flex items-center gap-1.5 text-gray-500 mb-4">
          <svg className="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          <span className="text-sm truncate">{listing.location}</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {listing.features.slice(0, 4).map((f) => (
            <span key={f} className="bg-gray-100 text-gray-600 text-xs px-2.5 py-1 rounded-lg font-medium">{f}</span>
          ))}
          {listing.features.length > 4 && (
            <span className="bg-theme-50 text-theme-dark text-xs px-2.5 py-1 rounded-lg font-medium">+{listing.features.length - 4} lagi</span>
          )}
        </div>
      </div>
    </div>
  );
}
