import { useListingsStore } from '../store';

interface Props {
  onTenantRegisterClick: () => void;
  onContactClick: () => void;
}

export default function Footer({ onTenantRegisterClick, onContactClick }: Props) {
  const { settings: s } = useListingsStore();

  return (
    <footer id="hubungi" className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-theme-gradient rounded-3xl p-8 sm:p-12 text-center shadow-xl">
          <h2 className="text-2xl sm:text-4xl font-extrabold mb-4">{s.footerCtaTitle}</h2>
          <p className="text-white/80 text-lg max-w-xl mx-auto mb-8 leading-relaxed">{s.footerCtaDescription}</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button onClick={onTenantRegisterClick}
              className="w-full sm:w-auto bg-white px-8 py-4 rounded-2xl font-bold text-lg hover:bg-gray-100 transition-colors shadow-2xl flex items-center justify-center gap-2"
              style={{ color: 'var(--theme-primary-dark)' }}>
              📝 {s.footerCtaButtonText}
            </button>
            <button onClick={onContactClick}
              className="w-full sm:w-auto bg-white/20 text-white border border-white/40 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-white/30 transition-colors text-center flex items-center justify-center gap-2">
              💬 WhatsApp / Hubungi Kami
            </button>
          </div>
        </div>
      </div>

      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="sm:col-span-2 lg:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <span className="text-2xl">{s.logoEmoji}</span>
                <span className="text-xl font-bold">{s.siteName}</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">{s.footerDescription}</p>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Kategori Perumahan</h4>
              <ul className="space-y-2">
                <li><a href="#kategori" className="text-gray-400 hover:text-white transition-colors text-sm">{s.catBilikIcon} {s.catBilikName}</a></li>
                <li><a href="#kategori" className="text-gray-400 hover:text-white transition-colors text-sm">{s.catRumahIcon} {s.catRumahName}</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Lokasi Popular</h4>
              <ul className="space-y-2">
                <li><span className="text-gray-400 text-sm">Kuala Lumpur & Lembah Klang</span></li>
                <li><span className="text-gray-400 text-sm">Selangor</span></li>
                <li><span className="text-gray-400 text-sm">Pulau Pinang</span></li>
                <li><span className="text-gray-400 text-sm">Johor Bahru</span></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Hubungi Kami</h4>
              <ul className="space-y-3">
                <li className="text-gray-400 text-sm flex items-center gap-2">
                  <span>📧</span> <a href={`mailto:${s.contactEmail}`} className="hover:text-white transition-colors">{s.contactEmail}</a>
                </li>
                <li className="text-gray-400 text-sm flex items-center gap-2">
                  <span>💬</span> <a href={`https://wa.me/${s.contactWhatsappInt}`} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">{s.contactWhatsapp} (WhatsApp)</a>
                </li>
                <li className="text-gray-400 text-sm flex items-center gap-2">
                  <span>📞</span> <a href={`tel:${s.contactPhone}`} className="hover:text-white transition-colors">{s.contactPhoneDisplay}</a>
                </li>
                <li className="text-gray-400 text-sm flex items-center gap-2">
                  <span>📍</span> {s.contactAddress}
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-gray-500 text-sm">{s.footerCopyright}</p>
            <div className="flex items-center gap-6">
              <span className="text-gray-500 hover:text-white transition-colors text-sm cursor-pointer">Dasar Privasi</span>
              <span className="text-gray-500 hover:text-white transition-colors text-sm cursor-pointer">Terma & Syarat</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
