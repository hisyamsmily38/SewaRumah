import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Listing, defaultListings } from './data/listings';

export interface Tenant {
  id: number;
  name: string;
  phone: string;
  email: string;
  preferredCategory: 'bilik' | 'rumah' | 'mana-mana';
  budget: number;
  moveInDate: string;
  notes: string;
  targetListing?: string;
  createdAt: string;
}

export type AdminRole = 'main' | 'staff' | null;

export interface SiteSettings {
  // === BRANDING ===
  siteName: string;
  siteTagline: string;
  logoEmoji: string;
  logoImage: string; // base64 or URL

  // === HERO BACKGROUND ===
  heroBackgroundImage: string; // base64 or URL

  // === COLORS ===
  primaryColor: string;

  // === HERO ===
  heroBadgeText: string;
  heroTitleLine1: string;
  heroTitleLine2: string;
  heroDescription: string;
  heroCtaEmoji: string;
  heroCtaText: string;
  heroSecondaryCtaEmoji: string;
  heroSecondaryCtaText: string;
  heroStat1Value: string;
  heroStat1Label: string;
  heroStat2Value: string;
  heroStat2Label: string;
  heroStat3Value: string;
  heroStat3Label: string;

  // === CATEGORIES ===
  catBilikName: string;
  catBilikIcon: string;
  catBilikDesc: string;
  catRumahName: string;
  catRumahIcon: string;
  catRumahDesc: string;

  // === CONTACT ===
  contactPhone: string;
  contactPhoneDisplay: string;
  contactWhatsapp: string;
  contactWhatsappInt: string;
  contactEmail: string;
  contactAddress: string;
  contactHoursWeekday: string;
  contactHoursWeekend: string;

  // === FOOTER ===
  footerCtaTitle: string;
  footerCtaDescription: string;
  footerCtaButtonText: string;
  footerDescription: string;
  footerCopyright: string;

  // === TENANT FORM ===
  tenantFormHeading: string;
  tenantFormSubheading: string;
  tenantFormWhyTitle: string;
  tenantFormWhyDesc: string;
  tenantFormBenefit1: string;
  tenantFormBenefit2: string;
  tenantFormBenefit3: string;

  // === ADMIN CREDENTIALS ===
  mainAdminPassword: string;
  staffAdminPassword: string;
}

export const defaultSettings: SiteSettings = {
  siteName: 'RumahSewa',
  siteTagline: 'Cari Perumahan Ideal Anda',
  logoEmoji: '🏡',
  logoImage: '',
  heroBackgroundImage: '',

  primaryColor: '#059669',

  heroBadgeText: 'Platform Sewa Perumahan Pilihan Malaysia',
  heroTitleLine1: 'Cari Rumah & Bilik',
  heroTitleLine2: 'Impian Anda',
  heroDescription: 'Semak ratusan unit rumah dan bilik sewa. Ingin kami carikan unit yang sepadan dengan bajet anda? Daftar terus sebagai bakal penyewa.',
  heroCtaEmoji: '🔍',
  heroCtaText: 'Cari Senarai',
  heroSecondaryCtaEmoji: '📝',
  heroSecondaryCtaText: 'Daftar Bakal Penyewa',
  heroStat1Value: '500+',
  heroStat1Label: 'Senarai Aktif',
  heroStat2Value: '10K+',
  heroStat2Label: 'Penyewa Terdaftar',
  heroStat3Value: '50+',
  heroStat3Label: 'Lokasi',

  catBilikName: 'Sewa Bilik',
  catBilikIcon: '🛏️',
  catBilikDesc: 'Bilik peribadi & kongsi',
  catRumahName: 'Sewa Rumah',
  catRumahIcon: '🏠',
  catRumahDesc: 'Rumah teres, banglo & bungalow',

  contactPhone: '012-345 6789',
  contactPhoneDisplay: '012-345 6789',
  contactWhatsapp: '012-345 6789',
  contactWhatsappInt: '60123456789',
  contactEmail: 'info@rumahsewa.my',
  contactAddress: 'Kuala Lumpur, Malaysia',
  contactHoursWeekday: '9.00 Pagi - 6.00 Petang',
  contactHoursWeekend: '10.00 Pagi - 4.00 Petang',

  footerCtaTitle: 'Sedang Mencari Bilik atau Rumah Sewa?',
  footerCtaDescription: 'Daftar profil dan keperluan anda sebagai bakal penyewa. Pemilik rumah dan ejen perumahan kami akan membantu padankan unit terbaik untuk anda.',
  footerCtaButtonText: 'Daftar Sebagai Penyewa',
  footerDescription: 'Platform pencarian perumahan nombor satu di Malaysia. Kami membantu anda mencari rumah atau bilik idaman dan menghubungkan bakal penyewa dengan tuan rumah.',
  footerCopyright: '© 2025 RumahSewa. Hak Cipta Terpelihara.',

  tenantFormHeading: 'Daftar Sebagai Bakal Penyewa',
  tenantFormSubheading: 'Isi maklumat di bawah untuk dihubungi oleh pihak pengurusan',
  tenantFormWhyTitle: 'Mengapa daftar di RumahSewa?',
  tenantFormWhyDesc: 'Sistem pendaftaran penyewa direka untuk menjimatkan masa anda. Masukkan maklumat keperluan dan bajet anda, dan pihak kami serta rangkaian pemilik rumah akan mencari dan memadankan unit yang tepat untuk anda secara PERCUMA.',
  tenantFormBenefit1: 'Tiada Cas Tersembunyi',
  tenantFormBenefit2: 'Padanan Eksklusif',
  tenantFormBenefit3: 'Maklumat Selamat',

  mainAdminPassword: 'Hisyam97@',
  staffAdminPassword: 'Admin',
};

// === COLOR UTILITIES ===
function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? { r: parseInt(result[1], 16), g: parseInt(result[2], 16), b: parseInt(result[3], 16) }
    : { r: 5, g: 150, b: 105 };
}

function rgbToHex(r: number, g: number, b: number): string {
  return '#' + [r, g, b].map((x) => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, '0')).join('');
}

export function adjustColor(hex: string, amount: number): string {
  const { r, g, b } = hexToRgb(hex);
  return rgbToHex(r + amount, g + amount, b + amount);
}

export function colorWithAlpha(hex: string, alpha: number): string {
  const { r, g, b } = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export const themePresets = [
  { name: 'Hijau Emerald', color: '#059669', emoji: '🌿' },
  { name: 'Biru Lautan', color: '#0284c7', emoji: '🌊' },
  { name: 'Ungu Megah', color: '#7c3aed', emoji: '💜' },
  { name: 'Merah Delima', color: '#dc2626', emoji: '❤️' },
  { name: 'Jingga Ceria', color: '#ea580c', emoji: '🍊' },
  { name: 'Teal Tenang', color: '#0d9488', emoji: '🌊' },
  { name: 'Merah Jambu', color: '#db2777', emoji: '🌸' },
  { name: 'Emas Berkilau', color: '#d97706', emoji: '✨' },
  { name: 'Perak Moden', color: '#475569', emoji: '🪙' },
  { name: 'Indigo Malam', color: '#4f46e5', emoji: '🌙' },
];

// === STORE ===
interface ListingStore {
  listings: Listing[];
  addListing: (data: Omit<Listing, 'id'>) => void;
  updateListing: (id: number, data: Partial<Listing>) => void;
  deleteListing: (id: number) => void;
  resetListings: () => void;

  tenants: Tenant[];
  addTenant: (data: Omit<Tenant, 'id' | 'createdAt'>) => void;
  deleteTenant: (id: number) => void;

  settings: SiteSettings;
  updateSettings: (data: Partial<SiteSettings>) => void;
  resetSettings: () => void;
  resetAll: () => void;

  adminRole: AdminRole;
  loginAdmin: (role: AdminRole) => void;
  logoutAdmin: () => void;
}

const getCurrentMaxId = (items: { id: number }[]) => {
  if (items.length === 0) return 0;
  return Math.max(...items.map((i) => i.id));
};

export const useListingsStore = create<ListingStore>()(
  persist(
    (set) => ({
      listings: defaultListings,
      addListing: (data) => {
        set((state) => ({
          listings: [...state.listings, { ...data, id: getCurrentMaxId(state.listings) + 1 }],
        }));
      },
      updateListing: (id, data) => {
        set((state) => ({
          listings: state.listings.map((l) => (l.id === id ? { ...l, ...data } : l)),
        }));
      },
      deleteListing: (id) => {
        set((state) => ({
          listings: state.listings.filter((l) => l.id !== id),
        }));
      },
      resetListings: () => {
        set({ listings: defaultListings });
      },

      tenants: [],
      addTenant: (data) => {
        set((state) => ({
          tenants: [
            { ...data, id: getCurrentMaxId(state.tenants) + 1, createdAt: new Date().toLocaleDateString('ms-MY') },
            ...state.tenants,
          ],
        }));
      },
      deleteTenant: (id) => {
        set((state) => ({
          tenants: state.tenants.filter((t) => t.id !== id),
        }));
      },

      settings: defaultSettings,
      updateSettings: (data) => {
        set((state) => ({
          settings: { ...state.settings, ...data },
        }));
      },
      resetSettings: () => {
        set({ settings: defaultSettings });
      },
      resetAll: () => {
        set({ listings: defaultListings, tenants: [], settings: defaultSettings });
      },

      adminRole: null,
      loginAdmin: (role) => {
        set({ adminRole: role });
      },
      logoutAdmin: () => {
        set({ adminRole: null });
      },
    }),
    {
      name: 'rumahsewa_store',
      partialize: (state) => ({
        listings: state.listings,
        tenants: state.tenants,
        settings: state.settings,
      }),
    }
  )
);
