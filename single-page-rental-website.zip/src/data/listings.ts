export type Category = 'bilik' | 'rumah';

export interface Listing {
  id: number;
  title: string;
  category: Category;
  price: number;
  location: string;
  image: string;
  description: string;
  features: string[];
  contact: string;
}

export type CategoryOption = {
  id: Category;
  label: string;
  icon: string;
  desc: string;
};

export const categories: CategoryOption[] = [
  { id: 'bilik', label: 'Sewa Bilik', icon: '🛏️', desc: 'Bilik peribadi & kongsi' },
  { id: 'rumah', label: 'Sewa Rumah', icon: '🏠', desc: 'Rumah teres, banglo & bungalow' },
];

export const defaultListings: Listing[] = [
  {
    id: 1,
    title: 'Bilik Selesa di Bandar Baru Bangi',
    category: 'bilik',
    price: 450,
    location: 'Bandar Baru Bangi, Selangor',
    image: '/images/room1.jpg',
    description: 'Bilik peribadi yang selesa dan moden. Sesuai untuk pelajar dan profesional muda. Kedudukan strategik berhampiran universiti dan pusat membeli-belah. Bilik dilengkapi dengan katil, almari, meja belajar dan kipas. Perkhidmatan WiFi percuma disediakan.',
    features: ['WiFi Percuma', 'Katil Double', 'Almari', 'Meja Belajar', 'Kipas', 'Basikal'],
    contact: '012-345 6789',
  },
  {
    id: 2,
    title: 'Bilik Murah Berhampiran USM',
    category: 'bilik',
    price: 350,
    location: 'Gelugor, Pulau Pinang',
    image: '/images/room2.jpg',
    description: 'Bilik kongsi yang bersih dan terang. Sesuai untuk pelajar universiti. Kedudukan sangat strategik, hanya 5 minit berjalan ke USM. Teras dan dapur dikongsi bersama. Air dan elektrik berpatutan.',
    features: ['WiFi Percuma', 'Katil Single', 'Kipas Angin', 'Dapur Kongsi', 'Basikal', 'Parkir'],
    contact: '013-456 7890',
  },
  {
    id: 3,
    title: 'Bilik Single di Sunway',
    category: 'bilik',
    price: 650,
    location: 'Sunway, Kuala Lumpur',
    image: '/images/room3.jpg',
    description: 'Bilik peribadi premium di kawasan Sunway. Keluar terus ke LRT dan Sunway Pyramid Mall. Bilik dihias dengan gaya moden, dilengkapi semua perabot asas. Sesuai untuk profesional yang bekerja di KL.',
    features: ['WiFi Percuma', 'Aircond', 'Katil Queen', 'Almari', 'Kuliner', 'Ke LRT'],
    contact: '017-890 1234',
  },
  {
    id: 4,
    title: 'Rumah Teres 3 Bilik Melawati',
    category: 'rumah',
    price: 2200,
    location: 'Taman Melawati, Kuala Lumpur',
    image: '/images/house1.jpg',
    description: 'Rumah teres dua tingkat yang cantik dan terawat. 3 bilik tidur, 2 bilik air, dapur yang luas dan ruang tamu yang selesa. Sesuai untuk keluarga kecil. Keluar terus ke LRT Melawati dan pusat beli-belah.',
    features: ['3 Bilik Tidur', '2 Bilik Air', '2 Petak Parking', 'Taman Depan', 'Aircond', 'Taman Belakang'],
    contact: '019-234 5678',
  },
  {
    id: 5,
    title: 'Bungalow Mewah di Bangsar',
    category: 'rumah',
    price: 6500,
    location: 'Bangsar, Kuala Lumpur',
    image: '/images/house2.jpg',
    description: 'Rumah banglo mewah di kawasan premium Bangsar. 5 bilik tidur, 4 bilik air, kolam renang peribadi, taman luas dan ruang tamu yang megah. Sistem keselamatan canggih.',
    features: ['5 Bilik Tidur', '4 Bilik Air', 'Kolam Renang', 'Taman Luas', 'CCTV', '3 Petak Parking'],
    contact: '016-345 6789',
  },
  {
    id: 6,
    title: 'Rumah Setingkat di Johor Bahru',
    category: 'rumah',
    price: 1500,
    location: 'Taman Mount Austin, Johor Bahru',
    image: '/images/house3.jpg',
    description: 'Rumah setingkat yang selesa di Mount Austin, kawasan popular JB. 3 bilik tidur, 2 bilik air, dapur moden dan ruang makan yang luas. Berhampiran restoran dan kafe terkenal.',
    features: ['3 Bilik Tidur', '2 Bilik Air', '1 Petak Parking', 'Dapur Moden', 'WiFi', 'Balkoni'],
    contact: '018-567 8901',
  },
];
